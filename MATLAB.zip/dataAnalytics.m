% dataAnalytics
% Tyler Heiman 04/11/2022
%
% Purpose: to provide simple data analysis statistics

%% Data Analysis

function [dc,Avg,Std] = dataAnalytics(data,hist,clean)
tally = 0;
Zmin = 0;
Zmax = 0;

leng = length(data);
avg = mean(data);
stdv = std(data);
temp = zeros(1,leng);

%fprintf("Initial Average: %f, Initial Standard Deviation: %f\n",avg,stdv);

% Determine interquartile range
srt = sort(data);
q2 = median(srt);

if ~mod(leng,2) % Even number of data points
    lower = srt(1:(leng/2));
    upper = srt(((leng/2)+1):leng);
    q1 = median(lower);
    q3 = median(upper);
else
    mid = ceil(leng/2);
    lower = srt(1:mid);
    upper = srt(mid:leng);
    q1 = median(lower);
    q3 = median(upper);
end

iqr = q3-q1;
lif = q1 - iqr*1.5;
uif = q3 + iqr*1.5;


for i = 1:leng
    z = data(i);
    if z < uif && z > lif
        temp(i) = data(i);
    else
        tally = tally + 1;
        if z < Zmin
            Zmin = z;
        elseif z > Zmax
            Zmax = z;
        end
    end
end

fprintf("Total Outliers Removed: %d, Zmin: %f, Zmax: %f\n",tally,Zmin,Zmax);

if clean
    nt = nonzeros(temp);
    dc = nt';

    Avg = mean(dc);
    Std = std(dc);
else
    dc = temp;
end

if hist
    histogram(dc);
end

end