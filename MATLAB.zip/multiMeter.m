%Multimeter
%Joseph Broadway 8/20/21
%Callable function to read ac voltage, average, and output

function [Vav] = multiMeter(v,samples)

%automatically detect minimum range from 0.1, 1, 10, 100, 1000 V

vrms = v/sqrt(2);
vArray = zeros(1,samples);
if vrms < 0.1
    vRange = 0.1;
elseif vrms < 1
    vRange = 1;
elseif vrms < 10
    vRange = 10;
elseif vrms < 100
    vRange = 100;
elseif vrms < 1000
    vRange = 1000;
end

Multimeter = visa('keysight','USB0::0x0957::0x4918::MY59100011::0::INSTR');

fopen(Multimeter);

pause(1)
%fprintf(Multimeter,sprintf( 'MEAS:VOLT:AC? %d',vRange));
for n = 1:samples
    fprintf(Multimeter,sprintf( 'MEAS:VOLT:AC? %d',vRange));
    
    vArray(n) = str2num(fscanf(Multimeter)); %CREATE MATRIX OF VALUES (5 TOTAL)
end

fclose(Multimeter);
delete(Multimeter);

% disp(vArray);
Vav = mean(vArray);

end