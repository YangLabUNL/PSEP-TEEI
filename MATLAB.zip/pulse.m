 function [] = pulse(v,n,f,pw,chrg,plst,glst,a)
% clc;
%TODO: Error bound short duration, low freq and low num, short pulse
%duration is critical; %integrate pulse counter into the system;

%f is frequency (Hz)
%v is Voltage
%nm is the number of pulses, this is used to calculate the required output
%time
%pw is the pulse width in seconds

% v =1; %2/33/2; v=X/2 with amp, v=X/2/33 with no amp %10 %Volts
% n = 400; %1000 %the number of pulses
% f = 50; %5 %(Hz)
% pw = 0.01;%0.19999; %0.1 %pulse width (s), must be less than the period: T (s) = 1/f

usbF = 'USB0::0x0957::0x3C18::MY58370004::0::INSTR'; % USB address for the function generator
tab = '';%'';%'Ikhlaas';

%% Arduino Set-up

% create arduino
% a = arduino('COM3','Mega2560','Libraries','SPI');

% assign pins
amp = "D41";   % Relay Pins
vm1 = "D39";
vm2 = "D37";
vm3 = "D33";
in1 = "D44";
in2 = "D45";
in3 = "D35";
pDir = "D51";
nDir = "D53";
a6 = "D14";
a5 = "D15";
a4 = "D16";
a3 = "D17";
a2 = "D18";
a1 = "D19";
c6 = "D7";
c5 = "D6";
c4 = "D5";
c3 = "D4";
c2 = "D3";
c1 = "D2";
w1 = "D28";
w2 = "D26";
w3 = "D24";
w4 = "D25";
w5 = "D27";
w6 = "D29";

%% Truth Tables

% Amplifier Pin
% PWR OUT
%  0   No Amp
%  1   Amp Used

% Voltmeter Pins
% VM1 VM2 Out
%  0   0   In-line Load Measurement
%  0   1   In-line System Measurement
%  1   0   Four Electrode Measurement
%  1   1   Four Electrode Measurement

% Counter Control
% s1 s2 Out
% 0  0  Clear
% 0  1  Count Down
% 1  0  Load
% 1  1  Count Up
% Note: ENP & ENT must both be LOW (0) to count

% Load Relay Pins
% IN3 IN2 IN1 Out
%  0   0   0   100k Load
%  0   0   1   50k Load
%  0   1   0   10k Load
%  0   1   1   1k Load
%  1   0   0   100 Ohm Load
%  1   0   1   Bypass
%  1   1   0   Open
%  1   1   1   Open

%%
% if v > 10
%     writeDigitalPin(a,cnth,1);
% else
%     writeDigitalPin(a,cntl,1);
% end

% Ensure All Relays Start Open
writeDigitalPin(a,amp,0);
writeDigitalPin(a,vm1,0);
writeDigitalPin(a,vm2,0);
writeDigitalPin(a,vm3,0);
writeDigitalPin(a,in1,1);
writeDigitalPin(a,in2,1);
writeDigitalPin(a,in3,1);
writeDigitalPin(a,pDir,0);
writeDigitalPin(a,nDir,0);
writeDigitalPin(a,a4,0);
writeDigitalPin(a,a5,0);
writeDigitalPin(a,a6,0);
writeDigitalPin(a,a3,0);
writeDigitalPin(a,a2,0);
writeDigitalPin(a,a1,0);
writeDigitalPin(a,c3,0);
writeDigitalPin(a,c2,0);
writeDigitalPin(a,c1,0);
writeDigitalPin(a,c4,0);
writeDigitalPin(a,c5,0);
writeDigitalPin(a,c6,0);
writeDigitalPin(a,w1,0);
writeDigitalPin(a,w2,0);
writeDigitalPin(a,w3,0);
writeDigitalPin(a,w4,0);
writeDigitalPin(a,w5,0);
writeDigitalPin(a,w6,0);

if v > 5
    writeDigitalPin(a,amp,1);
    v = v/33;
end

v = v/2;

t1 = 1.98; %error time constant in seconds. Its the time for the function generator to ouput the signal

to = n/f;% the calculated amount of time the output signal should be on. Calculated by the number of pulses divided by the frequency.
tm = to; % the amount of time matlab should pause in order to make the right output signal length

voff = v/2; % the offset to make the square wave lower voltage be zero

if pw<1/f %the pulse width (s) must be less than the period (s)
    D = pw*f*100; %the duty cycle is calculated by the ratio of pulse width to period, or pulse width (s) times the frequency (Hz)
else
    %print error and stop program
    fprintf('ERROR: The pulse width must be less than the period: %d seconds.\n', 1/f);
    return;
end

%%

% if strcmp(opt1,'Positive Payload')
if strcmp(tab,'Ikhlaas')
    disp('Using Ikhlaas tab')
    for k = 1:length(plst)
        switch plst{k}
            case 1
                writeDigitalPin(a,a6,1);
            case 2
                writeDigitalPin(a,a5,1);
            case 3
                writeDigitalPin(a,a4,1);
            case 4
                writeDigitalPin(a,a3,1);
            case 5
                writeDigitalPin(a,a2,1);
            case 6
                writeDigitalPin(a,a1,1);
        end
    end
    
    for m = 1:length(glst)
        switch glst{m}
            case 1
                writeDigitalPin(a,c1,1);
            case 2
                writeDigitalPin(a,c2,1);
            case 3
                writeDigitalPin(a,c3,1);
            case 4
                writeDigitalPin(a,c4,1);
            case 5
                writeDigitalPin(a,c5,1);
            case 6
                writeDigitalPin(a,c6,1);
        end
    end
else
    for k = 1:length(plst)
        switch plst{k}
            case 1
                writeDigitalPin(a,w1,1);
            case 2
                writeDigitalPin(a,w2,1);
            case 3
                writeDigitalPin(a,w3,1);
            case 4
                writeDigitalPin(a,w4,1);
            case 5
                writeDigitalPin(a,w5,1);
            case 6
                writeDigitalPin(a,w6,1);
        end
    end
end

% % if strcmp(opt1,'Positive Payload')
% for k = 1:length(plst)
%     switch plst{k}
%         case 1
%             writeDigitalPin(a,w1,1);
%         case 2
%             writeDigitalPin(a,w2,1);
%         case 3
%             writeDigitalPin(a,w3,1);
%         case 4
%             writeDigitalPin(a,w4,1);
%         case 5
%             writeDigitalPin(a,w5,1);
%         case 6
%             writeDigitalPin(a,w6,1);
%     end
% end

% Check Current Direction
if strcmp(chrg,'Negative Payload') || strcmp(chrg,'N')
    disp('Negative Payload')
    writeDigitalPin(a,pDir,0);
    writeDigitalPin(a,nDir,1);
elseif strcmp(chrg,'Positive Payload')  || strcmp(chrg,'P')
    disp('Positive Payload')
    writeDigitalPin(a,pDir,1);
    writeDigitalPin(a,nDir,0);
else
    error('Unexpected Payload Polarity')
end

functionGen = visa('keysight',usbF);

fopen(functionGen);
fprintf(functionGen,'*CLS; *RST');
fprintf(functionGen,sprintf('APPL:PULS %d,%d VPP,%d',f,v,voff ) );% tells function generator to make a square wave at f frequency, v voltage, and voff voltage offset
fprintf(functionGen,sprintf('FUNC:PULS:DCYC %d',D)); %sets the duty cycle to the value calculated from the pulse width
fprintf(functionGen,'OUTP:LOAD INF');
fprintf(functionGen,'OUTP ON');
disp('START');

pause(2.5);

%Close Bipass
writeDigitalPin(a,in2,0);

pause(tm);

%Open Bipass Relay
writeDigitalPin(a,in2,1);

pause(2);

fprintf(functionGen, 'OUTP OFF');

disp('STOP');


fclose(functionGen);
delete(functionGen);

% Disconnect
writeDigitalPin(a,a4,0);
writeDigitalPin(a,a5,0);
writeDigitalPin(a,a6,0);
writeDigitalPin(a,a3,0);
writeDigitalPin(a,a2,0);
writeDigitalPin(a,a1,0);
writeDigitalPin(a,c3,0);
writeDigitalPin(a,c2,0);
writeDigitalPin(a,c1,0);
writeDigitalPin(a,c4,0);
writeDigitalPin(a,c5,0);
writeDigitalPin(a,c6,0);
writeDigitalPin(a,w1,0);
writeDigitalPin(a,w2,0);
writeDigitalPin(a,w3,0);
writeDigitalPin(a,w4,0);
writeDigitalPin(a,w5,0);
writeDigitalPin(a,w6,0);

end