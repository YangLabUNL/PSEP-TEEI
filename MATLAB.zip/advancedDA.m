% advancedDA
% Tyler Heiman 04/12/2022
%
% Purpose: To compare indiviudal groups of data and ensure there are enough
% statistcal similarities to confidently incude the groups in the data pool

%% Function
clear
clc
%function [pool,avg,stdv] = advancedDA(data,span)

data = {{3,6,2,8,5,9,4,3,66,8,1.6},{1,1,1,1,1,1,1,1,1,1,1};...
    {6,8,3,5,9,2,6,1,8,7},{2,2,2,2,2,2,2,2,2,2};...
    {23,74,21,85,36,47,35,46,35,66,},{3,3,3,3,3,3,3,3,3,3};...
    {2,5,3,7,35,8,4,52,7,3,9,2,5,4},{4,4,4,4,4,4,4,4,4,4,4,4,4,4}};

span = 4;

% Initializations
same = zeros(1,span*250);
gsame = zeros(1,span*250);
diff = zeros(250,span);
gdiff = zeros(250,span);
allData = zeros(1,span*250);
ns = 1;
nd = 0;

% Set starting comparison
d1 = cell2mat(data{1,1});
g1 = cell2mat(data{1,2});
same(1:length(d1)) = d1;
gsame(1:length(d1)) = g1;
l1 = length(d1);
ls = length(d1);
lf = 1;



%% Combine all data into a single array
for i = 1:span
    d = cell2mat(data{i,1});
    allData(lf:lf+length(d)-1) = d;
    lf = lf + length(d);
end

ftemp = nonzeros(allData);                      %Remove zeros 
allData = ftemp';                               %Final Array of data

%cAllData = dataAnalytics(allData,false,false);  %Remove Outliers from full data array
lc = 1;
lc2 = 1;

% Create arrays of data and groups of equal size, removing any zeros
for i = 1:span
   lg = length(data{i,1});
   dt = cAllData(lc:lc+lg-1);
   lc = lc+lg;
   
   dn = nonzeros(dt)';
   ln = length(dn);
   
   temp(lc2:lc2+ln-1) = dn;
   tempg(lc2:lc2+ln-1) = cell2mat(data{i,2}(1:length(dn)));
   lc2 = lc2+ln;
end

ndata = nonzeros(temp);                       %Remove any remaing zeros
ngroup = nonzeros(tempg);

nds = length(ndata);
ngs = length(ngroup);
ndMtx = zeros(span,nds);
ngMtx = zeros(span,ngs);
start = 1;

% Create Matrices with clean and sorted data and groups 
for i = 1:span
    grp = ngroup(start);
    temp = grp;
%     if i ~= 1
%         count = start-1;
%     else
%         count = start;
%     end
    count = start;
    while temp == grp
        count = count + 1;
        if count < nds+2
            temp = ngroup(count-1);
        else
            temp = 0;
        end
    end
    ndMtx(i,1:(count-start-1)) = ndata(start:count-2);
    ngMtx(i,1:(count-start-1)) = ngroup(start:count-2);
    start = count - 1;
end

%% Test Normality

norm = adtest(allData);

%% Test Variance

p = vartestn(ndata,ngroup);

%% Test Linearity

if span >= 3
   s = sort(allData);
   [cleanS,mu,sig] = dataAnalytics(s,false,true);
   pdf = normpdf(cleanS,mu,sig);
   sum1 = 0;
   sum2 = 0;
   for i = 1:length(cleanS)
      sum1 = sum1 + ((cleanS(i)-pdf(i))^2);
      sum2 = sum2 + ((cleanS(i)-mu)^2);
   end
   R2 = 1 - (sum1/sum2);
end

%% Test

if span == 2
    d1 = cell2mat(data{1,1});
    d2 = cell2mat(data{2,1});
    if largest < 30
       if norm == 0
          if p ~= 0
              [h,p2] = ttest2(d1,d2);
          else
              [h,p2] = ttest2(d1,d2,'Vartype','unequal');
          end
       else
           [p2,h2] = ranksum(d1,d2);
       end
    else
        [h,p2] = ttest2(d1,d2);
    end
else
    if norm == 0 && p ~= 0
       if R2 > 0.9
           % Run Anova Test    
           [p2,tbl,stats] = anova1(ndata,ngroup,'off');
       else
          % ANOVA with linearity test 
       end
    else
        [p2,tbl,stats] = kruskalwallis(ndata,ngroup,'off');
    end
end

%% Post-hoc

if span >= 3 && p2 > 0.05
    c = multcompare(stats);
end


%Final Data Smoothing
[pool,avg,stdv] = dataAnalytics(pt,false,true);

