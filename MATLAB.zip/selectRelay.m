% selectRelay
% Tyler Heiman 08/5/2022
%
% Purpose: To determine operate resistance relays based on a numerical
% input

function [] = selectRelay(n)
a = arduino('COM3','Mega2560','Libraries','SPI');
in1 = "D36";
in2 = "D32";
in3 = "D42";

bVal = dec2bin((n-1),3);
writeDigitalPin(a,in1,str2num(bVal(3)));
writeDigitalPin(a,in2,str2num(bVal(2)));
writeDigitalPin(a,in3,str2num(bVal(1)));
end