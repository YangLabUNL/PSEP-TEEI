% Board Test
% Tyler Heiman 8/8/22
%
% Purpose: To test the different PCB components

clear all
a = arduino('COM3','Mega2560','Libraries','SPI');

% assign pins
amp = "D34";   % Relay Pins
vm1 = "D38";
vm2 = "D40";
vm3 = "D44";
in1 = "D36";
in2 = "D32";
in3 = "D42";
cntl = "D24";
cnth = "D22";
a1 = "D19";
a2 = "D18";
a3 = "D17";
a4 = "D14";
a5 = "D15";
a6 = "D16";
c1 = "D5";
c2 = "D6";
c3 = "D7";
c4 = "D4";
c5 = "D3";
c6 = "D2";
ext = "D30";

% Ensure All Relays Start Open
writeDigitalPin(a,amp,0);
writeDigitalPin(a,vm1,0);
writeDigitalPin(a,vm2,0);
writeDigitalPin(a,vm3,1);
writeDigitalPin(a,in1,0);
writeDigitalPin(a,in2,0);
writeDigitalPin(a,in3,1);
writeDigitalPin(a,cntl,0);
writeDigitalPin(a,cnth,0);
writeDigitalPin(a,a4,0);
writeDigitalPin(a,a5,0);
writeDigitalPin(a,a6,0);
writeDigitalPin(a,a3,0);
writeDigitalPin(a,a2,0);
writeDigitalPin(a,a1,0);
writeDigitalPin(a,c3,0);
writeDigitalPin(a,c2,0);
writeDigitalPin(a,c1,0);
writeDigitalPin(a,c4,0);
writeDigitalPin(a,c5,0);
writeDigitalPin(a,c6,0);
writeDigitalPin(a,ext,1);