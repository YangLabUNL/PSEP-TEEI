%FunctionGen 1.0
%Joseph Broadway 8/20/21

function [] = funcGen(v,f)
functionGen = visa('keysight','USB0::0x0957::0x3C18::MY58370004::0::INSTR');

fopen(functionGen);

fprintf(functionGen,'*CLS; *RST');
fprintf(functionGen,'FUNC SIN');
fprintf(functionGen, sprintf('VOLT %d VPP', v)); %set output voltage vpp to input voltage
fprintf(functionGen, sprintf('FREQ %d', f)); %set output freq to input frequency
fprintf(functionGen,'VOLT:OFFS 0');
fprintf(functionGen,'OUTP:LOAD INF');
fprintf(functionGen,'OUTP ON');

fclose(functionGen);
delete(functionGen);
end