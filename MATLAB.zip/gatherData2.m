% gatherData V2
% Tyler Heiman 5/23/2022
%
% Purpose: To more efficiently gather desired data and remain compatiable
% with Main2

%% Data Grouping

% Want is the desired data ('Z' or 'V')
% Vars is a cell of specifications:
    % 1: Membrance
    % 2: Electrolyte
    % 3: Applied Voltage Amplitude
    % 4: Applied Frequency
    % 5: Date
    % Ex: {{},{'DIH20'},{'V5','V10'},{},{}}
        % The above example states that the code will look at the desired
        % data for all dates, frequencies, and membranes, but specifically
        % for DIH20 at 5 and 10 volts
% Sort specifies what you want to sort the data by through the use of the
% assigned numbers above. The default is frequency.
% Sort2 provides a secondary sorting option to create 3d matrices of data.
% The defualt is voltage. (NOTE: Sort and Sort2 cannot be the same)

function [] = gatherData2(vars,sort,anlz,want)

% Testing Inputs
%     start = datetime(2022,04,4);
%     stop = datetime(2022,04,5);
%

% vars = {{},{},{},{},{'1_uM_NaCl','NaCl'},{'200nm','400nm'},{'Sine'},{1.5,5},{2500,50,500}};
% sort = 5;

% anlz = false;

folder = 'C:\Users\tchei\OneDrive\Documents\Thesis\ESYS'; %Location of Data file
filename = 'data_lib.xlsx';
if isfile(filename)
    Tbl = readtable(filename);
else
    error("Named file does not exist");
end

date_start = datetime(2022,04,4);
Headers = {'Date','Time','Cell Type','Cell Density','Cell Duration',...
    'Electrolyte','Membrane','Waveform','Applied Voltage','Frequency','Z','V'};
data = {};

% Save the Specific Instances you wish too collect
vars1 = vars{1};
vars2 = vars{2};
vars3 = vars{3};
vars4 = vars{4};
vars5 = vars{5};
vars6 = vars{6};
vars7 = vars{7};
vars8 = vars{8};
vars9 = vars{9};

% Determine Time Span Being Searched
if ~isempty(vars{1})
    d1 = vars1{1};
    d2 = vars1{2};
    dif1 = time2num(d1-date_start,"days")+1;
    span = time2num(d2-d1,"days")+1;
else
    span = 1;
end

for x = 1:height(Tbl)
    
    tr1 = false;
    tr2 = false;
    tr3 = false;
    tr4 = false;
    tr5 = false;
    tr6 = false;
    tr7 = false;
    tr8 = false;
    tr9 = false;
    
    % Get Specified Data
    if ~isempty(vars1)                      % Check for match if desired
        for i = 1:span
            if isbetween(cell2mat(Tbl{x,1}),vars1{1},vars1{2})
                tr1 = true;
                break;
            end
        end
    else
        tr1 = true;
    end
    if ~isempty(vars2)
        for j = 1:length(vars2)
           if strcmp(cell2mat(Tbl{x,3}),vars2{j})
              tr2 = true;
              break;
           end
        end
    else
        tr2 = true;
    end
    if ~isempty(vars3)
        for k = 1:length(vars3)
            if strcmp(cell2mat(Tbl{x,4}),vars3{k})
              tr3 = true;
              break;
           end
        end
    else
        tr3 = true;
    end
    if ~isempty(vars4)
        for l = 1:length(vars4)
            if strcmp(cell2mat(Tbl{x,5}),vars4{l})
              tr4 = true;
              break;
           end
        end
    else
        tr4 = true;
    end
    if ~isempty(vars5)
        for m = 1:length(vars5)
            if strcmp(cell2mat(Tbl{x,6}),vars5{m})
              tr5 = true;
              break;
           end
        end
    else
        tr5 = true;
    end
    if ~isempty(vars6)
        for n = 1:length(vars6)
            if strcmp(cell2mat(Tbl{x,7}),vars6{n})
              tr6 = true;
              break;
           end
        end
    else
        tr6 = true;
    end
    if ~isempty(vars7)
        for o = 1:length(vars7)
            if strcmp(cell2mat(Tbl{x,8}),vars7{o})
              tr7 = true;
              break;
           end
        end
    else
        tr7 = true;
    end
    if ~isempty(vars8)
        for p = 1:length(vars8)
           if Tbl{x,9} == vars8{p}
               tr8 = true;
               break;
           end
        end
    else
        tr8 = true;
    end
    if ~isempty(vars9)
        for q = 1:length(vars9)
           if Tbl{x,10} == vars9{q}
               tr9 = true;
               break;
           end
        end
    else
        tr9 = true;
    end
    
    if tr1 && tr2 && tr3 && tr4 && tr5 && tr6 && tr7 && tr8 && tr9
%         fprintf("Cleared\n");
        switch sort
            case 1
                sep = i;
                width = span;
            case 2
                sep = j;
                width = length(vars2);
            case 3
                sep = k;
                width = length(vars3);
            case 4
                sep = l;
                width = length(vars4);
            case 5
                sep = m;
                width = length(vars5);
            case 6
                sep = n;
                width = length(vars6);
            case 7
                sep = o;
                width = length(vars7);
            case 8
                sep = p;
                width = length(vars8);
            otherwise
                sep = q;
                width = length(vars9);
        end
        
        % Create or Update Data Cell Array
        tblWidth = (length(Headers)+2);
        if isempty(data)
%             fprintf("Pos 1\n");
            for r = 1:width
                for s = 1:length(Headers)
                    data{1,((r-1)*tblWidth)+s} = Headers{s};
                end
%                 fprintf("Itr. p\n");
            end
            fprintf("Headers Complete\n");
            
            data{2,((tblWidth*(sep-1))+1)} = cell2mat(Tbl{x,1});
            data{2,((tblWidth*(sep-1))+2)} = cell2mat(Tbl{x,2});
            data{2,((tblWidth*(sep-1))+3)} = cell2mat(Tbl{x,3});
            data{2,((tblWidth*(sep-1))+4)} = cell2mat(Tbl{x,4});
            data{2,((tblWidth*(sep-1))+5)} = cell2mat(Tbl{x,5});
            data{2,((tblWidth*(sep-1))+6)} = cell2mat(Tbl{x,6});
            data{2,((tblWidth*(sep-1))+7)} = cell2mat(Tbl{x,7});
            data{2,((tblWidth*(sep-1))+8)} = cell2mat(Tbl{x,8});
            data{2,((tblWidth*(sep-1))+9)} = Tbl{x,9};
            data{2,((tblWidth*(sep-1))+10)} = Tbl{x,10};
            data{2,((tblWidth*(sep-1))+11)} = Tbl{x,11};
            data{2,((tblWidth*(sep-1))+12)} = Tbl{x,12};
        else
            data_size = size(data);
            y = 1;
            while y <= data_size(1)
                if isempty(data{y,((tblWidth*(sep-1))+1)})
                    break;
                else
                    y = y + 1;
                end
            end
            
            data{y,((tblWidth*(sep-1))+1)} = cell2mat(Tbl{x,1});
            data{y,((tblWidth*(sep-1))+2)} = cell2mat(Tbl{x,2});
            data{y,((tblWidth*(sep-1))+3)} = cell2mat(Tbl{x,3});
            data{y,((tblWidth*(sep-1))+4)} = cell2mat(Tbl{x,4});
            data{y,((tblWidth*(sep-1))+5)} = cell2mat(Tbl{x,5});
            data{y,((tblWidth*(sep-1))+6)} = cell2mat(Tbl{x,6});
            data{y,((tblWidth*(sep-1))+7)} = cell2mat(Tbl{x,7});
            data{y,((tblWidth*(sep-1))+8)} = cell2mat(Tbl{x,8});
            data{y,((tblWidth*(sep-1))+9)} = Tbl{x,9};
            data{y,((tblWidth*(sep-1))+10)} = Tbl{x,10};
            data{y,((tblWidth*(sep-1))+11)} = Tbl{x,11};
            data{y,((tblWidth*(sep-1))+12)} = Tbl{x,12};
        end
    end
end

%% Run Data Analysis
if anlz
    % Organize Data
    gd = {};
    gn = {};
    sd = size(data);
    w = sd(2);
    for k = 1:(w/(length(Headers)+2))
        y = 1;
        while y <= sd(1)
            if isempty(data{y,want})
                break;
            else
                y = y + 1;
            end
        end
        for m =1:y
            gd{m} = data{m,want};
            gn{m} = k;
        end
        da{k,1} = gd;
        da{k,2} = gn;
    end
    % Analyze
    vdata = advancedDA(da);
end


%% Save File

n = 1;
filename = sprintf('%s_Specified_Data_%s.xlsx',date,num2str(n,'%02i'));
while isfile(filename)
   n = n + 1; 
   filename = sprintf('%s_Specified_Data_%s.xlsx',date,num2str(n,'%02i'));
end

xlswrite(filename,data);

end
