% Main V2
% Tyler Heiman 5/23/2022
%
% Purpose: To organize data in a way that is easily compatible with GUI

function Tb2 = Main2(ct,cDen,cDur,elt,mem,shape,ampf,samples,V,F)
%% Create Table on first run

folder = 'C:\Users\tchei\OneDrive\Documents\Thesis\ESYS'; %Location of Data file
filename = 'data_lib.xlsx';

sz = [1000,12];
varTypes = ["char","string","string","string","string","string",...
    "string","string","single","single","double","double"];
varNames = ["Date","Time","Cell Type","Cell Density",...
    "Cell Duration (hrs)","Electrolyte","Membrane","Waveform",...
    "Amplitude (V)","Frequency (Hz)","Measured Impedance","Measured Voltage"];

if ~isfile(filename)
    message = sprintf('Creating %s', filename);
    uiwait(warndlg(message));
    Tbl = table('Size',sz,'VariableTypes',varTypes,'VariableNames',varNames);
else
    Tbl = readtable(filename);
end

%% Create Single Experiment Table
clear Tb2

sz2 = [100,12];
Tb2 = table('Size',sz2,'VariableTypes',varTypes,'VariableNames',varNames);

%% Collect Data

% Testing Inputs
% ct = 'NA';
% cDen = 'NA';
% cDur = 'NA';
% mem = '400nm';
% elt = 'NaCl';
% shape = 'Sine';
% ampf = 'yes';
% samples = 5;
% V = [1.5,2.5,5,10];
% F = [250,500,1000,2500];

%amplifier
% G = 33; %amplifier gain

%multimeter and function generator
% multimeter = visa('keysight','USB0::0x0957::0x4918::MY59100011::0::INSTR');
% functionGen = visa('keysight','USB0::0x0957::0x3C18::MY58370004::0::INSTR');
% Rout =50;       %[50(0-5V), 4(10V), 2(25V)] ohm, function generator output resistance
% Cout =2e-3;     %[2e-3(0-5V), 5e-3(10V), 6e-3(25V)] F, function generator output capacitance
% R = 12;         %Relay resistane

t = 0;
for i = 1:height(Tbl)
   idx = Tbl{i,2};
   if ismissing(idx)
       break;
   else
       t = t + 1;
   end
end

for i = 1:length(V)
    for j = 1:length(F)
        
        new = {date,[],ct,cDen,cDur,elt,mem,shape,V(i),F(j),[],[]};
        
        [t,data_Z,data_V] = autoImpedanceAlt(V(i),F(j),ampf,shape,samples);
        
        time = t;
        impd = data_Z;
        volt = data_V;
        
        new{2} = time;
        new{11} = impd;
        new{12} = volt;
        
        pos = t+((i-1)*length(F))+j;
        pos2 = ((i-1)*length(F))+j;
        
        Tbl(pos,:) = new;
        Tb2(pos2,:) = new;
    end
end

%% Save Table

writetable(Tbl,filename);
end
