% ESYS 1.2
% Justin Brooks 11/4/21
% Joseph Broadway 8/20/21
% Tyler Heiman 5/25/22

%Requires funcGen.m and multiMeter.m

%CHANGES TO BE MADE
%add membrane, cell density, electrolyte data to excel
%fix sheet creation warning from first run
%fix time output not showing hours or AM/PM w/o clicking on it

function [t,data_Z,data_V] = ESYS1_2(V,F,amp,shape,samples)
%% MEASUREMENTS
%For each voltage and frequency pairing, run the function generator and
%call the multimeter function to measure and average voltage

%amplifier
G = 33; %amplifier gain

%multimeter and function generator
multimeter = visa('keysight','USB0::0x0957::0x4918::MY59100011::0::INSTR');
functionGen = visa('keysight','USB0::0x0957::0x3C18::MY58370004::0::INSTR');
Rout =50;       %[50(0-5V), 4(10V), 2(25V)] ohm, function generator output resistance
Cout =2e-3;     %[2e-3(0-5V), 5e-3(10V), 6e-3(25V)] F, function generator output capacitance
R = 12;         %Relay resistane

t = {datestr(now,'HH:MM:SS.FFF')};

%check if amplifier is in use
if strcmp(amp,'yes')
    funcGen(V/G,F);
else
    funcGen(V,F);
end

%measure voltage
data_V = multiMeter(V, samples);

%calculate impedance
if strcmp(shape, 'Sine')
    rms = 1/sqrt(2);
end
data_Z = (data_V/(V*rms-data_V))*(1/(2*pi*Cout*F)+Rout+R);
%
%     %display voltages and impedances in table
%     clc
%     T = table(F',Vav,Z,'VariableNames',...
%         {'Frequency (Hz)','Average Voltage (V)','Impedance (Ohms)'});
%     disp(T)

%     %Test Code
%     Vav = 5*rand;
%     Z = 50000*rand;
%
% Z_data = [timeList;Z];
% V_data = [timeList;Vav];

%% CLOSE OUT ELECTRONICS

fopen(functionGen);
fopen(multimeter);

fprintf(functionGen,'OUTP OFF');
%close out multimeter?

fclose(multimeter);
delete(multimeter);
fclose(functionGen);
delete(functionGen);

end