% autoImpedance
% Tyler Heiman 11/15/2022

% Purpose: Script designed to run impedance measurement independent of
% human interation through the use is arduino controlled digital
% potentiometers

% Requires funcGen.m and multiMeter.m
function [t,data_Z,data_V,data_V2] = autoImpedanceAlt(V,F,mtd,shape,samples,chrg,plst,glst,a)%,fgon,fgoff)
% clear
% clc
%% Inital Set-up
% tic;
% a = arduino('COM3','Mega2560','Libraries','SPI');
% assign pins
amp = "D41";   % Relay Pins
vm1 = "D39";
vm2 = "D37";
vm3 = "D33";
in1 = "D44";
in2 = "D45";
in3 = "D35";
pDir = "D51";
nDir = "D53";
a6 = "D14";
a5 = "D15";
a4 = "D16";
a3 = "D17";
a2 = "D18";
a1 = "D19";
c6 = "D7";
c5 = "D6";
c4 = "D5";
c3 = "D4";
c2 = "D3";
c1 = "D2";
w1 = "D28";
w2 = "D26";
w3 = "D24";
w4 = "D25";
w5 = "D27";
w6 = "D29";

%multimeter and function generator
multimeter = visa('keysight','USB0::0x0957::0x4918::MY59100011::0::INSTR');
functionGen = visa('keysight','USB0::0x0957::0x3C18::MY58370004::0::INSTR');

%% Truth Tables

% Amplifier Pin
% PWR OUT
%  0   No Amp
%  1   Amp Used

% Voltmeter Pins
% VM1 VM2 Out
%  0   0   In-line Load Measurement
%  0   1   In-line System Measurement
%  1   0   Four Electrode Measurement
%  1   1   Four Electrode Measurement

% Load Relay Pins
% IN3 IN2 IN1 Out
%  0   0   0   100k Load
%  0   0   1   50k Load
%  0   1   0   10k Load
%  0   1   1   1k Load
%  1   0   0   100 Ohm Load
%  1   0   1   Bypass
%  1   1   0   Open
%  1   1   1   Open

%% MEASUREMENTS

%For each voltage and frequency pairing, run the function generator and
%call the multimeter function to measure and average voltage

% fprintf('Flag 0 Time: %.4f\n',toc);
t = datestr(now,'HH:MM:SS.FFF');

% Ensure All Relays Start Open
writeDigitalPin(a,amp,0);
writeDigitalPin(a,vm1,0);
writeDigitalPin(a,vm2,0);
writeDigitalPin(a,vm3,0);
writeDigitalPin(a,in1,1);
writeDigitalPin(a,in2,1);
writeDigitalPin(a,in3,1);
writeDigitalPin(a,pDir,1);
writeDigitalPin(a,nDir,0);
writeDigitalPin(a,a4,0);
writeDigitalPin(a,a5,0);
writeDigitalPin(a,a6,0);
writeDigitalPin(a,a3,0);
writeDigitalPin(a,a2,0);
writeDigitalPin(a,a1,0);
writeDigitalPin(a,c3,0);
writeDigitalPin(a,c2,0);
writeDigitalPin(a,c1,0);
writeDigitalPin(a,c4,0);
writeDigitalPin(a,c5,0);
writeDigitalPin(a,c6,0);
writeDigitalPin(a,w1,0);
writeDigitalPin(a,w2,0);
writeDigitalPin(a,w3,0);
writeDigitalPin(a,w4,0);
writeDigitalPin(a,w5,0);
writeDigitalPin(a,w6,0);

% fprintf('Flag 1 Time: %.4f\n',toc);

% if strcmp(opt1,'Positive Payload')
for k = 1:length(plst)
    switch plst{k}
        case 1
            writeDigitalPin(a,w1,1);
        case 2
            writeDigitalPin(a,w2,1);
        case 3
            writeDigitalPin(a,w3,1);
        case 4
            writeDigitalPin(a,w4,1);
        case 5
            writeDigitalPin(a,w5,1);
        case 6
            writeDigitalPin(a,w6,1);
    end
end

% fprintf('Flag 2 Time: %.4f\n',toc);

if strcmp(shape, 'Sine')
    rms = 1/sqrt(2);
else
    rms = 0.5;
end

V_target = (V*rms)/2;

%check if amplifier is in use
if V > 5
    writeDigitalPin(a,amp,1);
    Vn = V/33;
else
    Vn = V;
end

% Check Current Direction
if strcmp(chrg,'Negative Payload')
    writeDigitalPin(a,pDir,0);
    writeDigitalPin(a,nDir,1);
end

% fprintf('Flag 3 Time: %.4f\n',toc);

% if fgon
    funcGen(Vn,F);
% end

% fprintf('Flag 4 Time: %.4f\n',toc);

if strcmp(mtd,'Four Electrode')
    writeDigitalPin(a,vm1,1);
else
    writeDigitalPin(a,vm3,1);
end

% fprintf('Flag 5 Time: %.4f\n',toc);

V_cur = 0;
Rp = 0;
R = 0;

relay = 5;
for k = 5:-1:1
    V_prev = V_cur;
    bVal = dec2bin((k-1),3);
    writeDigitalPin(a,in1,str2num(bVal(3)));
    writeDigitalPin(a,in2,str2num(bVal(2)));
    writeDigitalPin(a,in3,str2num(bVal(1)));
    switch k  
        case 1
            Rp = R;
            R = 100000;
        case 2
            Rp = R;
            R = 51000;
        case 3
            Rp = R;
            R = 10000;
        case 4
            Rp = R;
            R = 1000;
        case 5
%             Rp = R;
            R = 100;
    end
    %             pause(1);
    V_cur = multiMeter(V,samples);
    fprintf("Measured Voltage: %.2f, Current Resistance: %.2f\n",V_cur,R);
    if V_cur > V_target
        relay = relay - 1;
    else
        break;
    end
end

% fprintf('Flag 6 Time: %.4f\n',toc);

writeDigitalPin(a,vm1,0);
writeDigitalPin(a,vm3,1);
writeDigitalPin(a,vm2,1);               %Measured Input Voltage

% fprintf('Flag 7 Time: %.4f\n',toc);

if relay == 5          
    Vin = multiMeter(V,samples);
    fprintf("Measured Input Voltage: %.2f, Current Resistance: %.2f\n",Vin,R);
    Zsys = 12+R;
    data_Z = (V_cur/Vin)*Zsys;
    data_V = V_cur;
    data_V2 = Vin;
    fprintf("Resistance is less than 100 Ohms\n");
elseif relay == 0
    Vin = multiMeter(V,samples);
    fprintf("Measured Input Voltage: %.2f, Current Resistance: %.2f\n",Vin,R);
    Zsys = 12+R;
    data_Z = (V_cur/Vin)*Zsys;
    data_V = V_cur;
    data_V2 = Vin;
    fprintf("Resistance is greater than 100000 Ohms\n");
else
    ud = V_target - V_cur;
    ld = V_prev - V_target;
    if ud < ld
        Vin = multiMeter(V,samples);
        fprintf("Measured Input Voltage: %.2f, Current Resistance: %.2f\n",Vin,R);
        Zsys = 12+R;
        data_Z = (V_cur/Vin)*Zsys;
        data_V = V_cur;
        data_V2 = Vin;
    else
        bVal = dec2bin((relay),3);
        writeDigitalPin(a,in1,str2num(bVal(3)));
        writeDigitalPin(a,in2,str2num(bVal(2)));
        writeDigitalPin(a,in3,str2num(bVal(1)));
        Vin = multiMeter(V,samples);
        fprintf("Measured Input Voltage: %.2f, Current Resistance: %.2f\n",Vin,Rp);
        Zsys = 12+Rp;%SystemImpedance(Rp,F(j));
        data_Z = (V_prev/Vin)*Zsys;
        data_V = V_prev;
        data_V2 = Vin;
    end
end

% fprintf('Flag 8 Time: %.4f\n',toc);
       
if ~strcmp(mtd,'Four Electrode')
    data_Z = data_Z - 24;
end

% Disconnect
writeDigitalPin(a,a4,0);
writeDigitalPin(a,a5,0);
writeDigitalPin(a,a6,0);
writeDigitalPin(a,a3,0);
writeDigitalPin(a,a2,0);
writeDigitalPin(a,a1,0);
writeDigitalPin(a,c3,0);
writeDigitalPin(a,c2,0);
writeDigitalPin(a,c1,0);
writeDigitalPin(a,c4,0);
writeDigitalPin(a,c5,0);
writeDigitalPin(a,c6,0);
writeDigitalPin(a,w1,0);
writeDigitalPin(a,w2,0);
writeDigitalPin(a,w3,0);
writeDigitalPin(a,w4,0);
writeDigitalPin(a,w5,0);
writeDigitalPin(a,w6,0);

% fprintf('Flag 9 Time: %.4f\n',toc);

%% CLOSE OUT ELECTRONICS

fopen(multimeter);
fclose(multimeter);
delete(multimeter);

% if fgoff
    fopen(functionGen);
    fprintf(functionGen,'OUTP OFF');
    fclose(functionGen);
    delete(functionGen);
% end

% fprintf('Flag 10 Time: %.4f\n',toc);

end